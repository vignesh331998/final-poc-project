package com.cts;

import java.sql.*;


public class PlanDAOImpl implements PlanDAO {
	static Connection conn;
	static PreparedStatement ps;
	@Override
	public int add(Plan p) {
		// TODO Auto-generated method stub
		int i=0;
		try {
			conn=DBConnection.getConn();
			  ps = conn.prepareStatement("insert into detail1 values(?,?,?,?)");
		        ps.setString(1,p.getUsername()); 
	            ps.setString(2,p.getLocation());
	            ps.setString(3, p.getStartdate());
	            ps.setString(4, p.getEnddate());           
	            i = ps.executeUpdate();
	            conn.close();
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return i;
	}

	@Override
	public Plan getPlanDisplay (String username) {
		// TODO Auto-generated method stub
		//Plan p=new Plan();
		try {
					conn=DBConnection.getConn();
					ps=conn.prepareStatement("select * from detail1 where username=?");
					ps.setString(1, username);
					ResultSet rs=ps.executeQuery();
					while(rs.next())
					{
						System.out.println(rs.getString("location"));
						System.out.println(rs.getString("startdate"));
						System.out.println(rs.getString("enddate"));
					}
				}catch(Exception e)
				{
					System.out.println(e);
				}
		return null;
		
	}

}
