package com.cts;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Loginregister
 */
@WebServlet("/Loginregister")
public class Loginregister extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Loginregister() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String driverName = "com.mysql.jdbc.Driver";
		String connectionUrl = "jdbc:mysql://localhost:3306/";
		String dbName = "mydb";
		String userId = "vignesh";
		String pasword = "Vignesh@3398";

		try {
			Class.forName(driverName);
		} catch (ClassNotFoundException e) {
		e.printStackTrace();
		}
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		UserDAO ud=new UserDAOImpl();
	//	PlanDAO pd=new PlanDAOImpl();
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		String submitType=request.getParameter("submit");
		User u=ud.getUser(username, password);
	//	Plan p=pd.getPlanDisplay(username);
		if(submitType.equals("login")&& u!=null && u.getName()!=null) {
			  request.getRequestDispatcher("action.jsp").forward(request, response);;
		 		}
		//else if(submitType.equals("login") && u!=null && u.getName()!=null)
		else if(submitType.equals("register"))
		{
			try
			{
			connection = DriverManager.getConnection(connectionUrl+dbName+"?autoReconnect=true&useSSL=false", userId, pasword);
			String un=request.getParameter("username");
			statement=connection.createStatement();
			String sql="select username from detail where username='"+un+"'";
			resultSet = statement.executeQuery(sql);
			if(resultSet.next())
			{
				request.setAttribute("message","Username Already Registered!!!Choose Another Username!!!");
				request.getRequestDispatcher("register.jsp").forward(request, response);
			}
			else {
			u.setName(request.getParameter("name"));
			u.setPassword(password);
			u.setUsername(username);
			ud.insertUser(u);
			request.setAttribute("message1","Registered Successfully");
			request.getRequestDispatcher("login.jsp").forward(request, response);
			}
		}
			catch(Exception e) {
				e.printStackTrace();
			}
		}
		else {
			request.setAttribute("message1","Invalid Credentials");
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}
	}

	}

	
