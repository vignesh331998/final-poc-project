package com.cts;



public interface Myprovider {
String username="vignesh";
String password="Vignesh@3398";
String url="jdbc:mysql://localhost:3306/mydb?autoReconnect=true&useSSL=false";

}
