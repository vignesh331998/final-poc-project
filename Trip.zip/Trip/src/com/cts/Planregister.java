package com.cts;

import java.io.IOException;
//import java.sql.Connection;
//import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Planregister
 */
@WebServlet("/Planregister")
public class Planregister extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Planregister() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	PlanDAO pd=new PlanDAOImpl();
		String username=request.getParameter("username");
		String location=request.getParameter("location");
		String startdate=request.getParameter("startdate");
		String enddate=request.getParameter("enddate");
		String submitType=request.getParameter("submit");
		Plan p=pd.getPlanDisplay(username);
		 if(submitType.equals("submit")) {
			 p.setUsername(username);
			 p.setLocation(location);
			 p.setStartdate(startdate);
			 p.setEnddate(enddate);
			 pd.add(p);
			 request.setAttribute("location",p.getLocation());
			 request.setAttribute("startdate",p.getStartdate());
			 request.setAttribute("enddate",p.getEnddate());	
			 request.getRequestDispatcher("display.jsp").forward(request, response);
			}
		/*else if(submitType.equals("viewplan")) {
		pd.getPlanDisplay(username);
		request.setAttribute("location",p.getLocation());
		request.setAttribute("startdate",p.getStartdate());
		request.setAttribute("enddate",p.getEnddate());
		request.getRequestDispatcher("display.jsp").forward(request, response);
		} else{
			request.setAttribute("message","please fill the details");
			request.getRequestDispatcher("planlist.jsp").forward(request, response);
		}*/
		
	}

}
